package com.techhub.oops.inheritance;

/**
 * The Maruti class
 * 
 * @author ramniwash
 */
public class Maruti extends Car {

	@Override
	public String toString() {
		return "This is MARUTI";
	}
}
