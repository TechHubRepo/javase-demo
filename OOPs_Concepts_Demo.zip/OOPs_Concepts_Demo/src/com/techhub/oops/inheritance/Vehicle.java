package com.techhub.oops.inheritance;

/**
 * The Vehicle class
 * 
 * @author ramniwash
 */
public interface Vehicle {
	
	/**
	 * Starts the Vehicle
	 */
	public void start();
}
