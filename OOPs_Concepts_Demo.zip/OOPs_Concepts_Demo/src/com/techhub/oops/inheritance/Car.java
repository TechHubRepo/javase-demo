package com.techhub.oops.inheritance;

/**
 * The Car class
 * 
 * @author ramniwash
 */
public class Car {

	@Override
	public String toString() {
		return "This is CAR";
	}

}
