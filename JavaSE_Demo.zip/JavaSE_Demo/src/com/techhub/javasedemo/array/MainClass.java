package com.techhub.javasedemo.array;

public class MainClass {

	public static void main(String[] args) {

		System.out.println("**************** With Array ****************");

//		String[] arr = null;
//		arr = new String[5];
//		arr[0] = "A";
//		arr[1] = "Hello";
//		arr[2] = "UUU";
		
		String[] arr= {"Ram","Hello","Hai","Bharat","YYY","OOO","UUU"};
		
		System.out.println(arr[2]);
		
//		for (String b : arr) {
//			System.out.println(b);
//		}

	}

}
