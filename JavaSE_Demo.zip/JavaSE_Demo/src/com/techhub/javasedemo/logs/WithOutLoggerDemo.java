package com.techhub.javasedemo.logs;

public class WithOutLoggerDemo {

	public static void main(String[] args) {
		System.err.println("Hello World");
		System.err.println("Welcome to Java Programming Language Course");
	}
}
