package com.techhub.javasedemo.p1;

import com.techhub.javasedemo.modifiers.Hello;

public class Hi extends Hello{

	public void testMethodHi(){
		
		/** Default variable can't be accessed from other package*/
//		System.out.println(f2);
		System.out.println(f3);
		System.out.println(f4);
	}
}
