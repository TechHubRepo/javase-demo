package com.techhub.javasedemo.typecasting;

public class B extends A{

	public String methodB() {
		return "methodB() -> Class B";
	}
}
