package com.techhub.javasedemo.typecasting;

public class A {

	public String methodA() {
		return "methodA() -> Class A";
	}
}
