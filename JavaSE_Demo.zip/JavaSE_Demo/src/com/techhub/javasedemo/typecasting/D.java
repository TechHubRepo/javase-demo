package com.techhub.javasedemo.typecasting;

public class D extends C {

	public String methodD() {
		return "methodD() -> Class D";
	}
}
