package com.techhub.javasedemo.typecasting;

public class C extends B {

	public String methodC() {
		return "methodC() -> Class C";
	}

}
