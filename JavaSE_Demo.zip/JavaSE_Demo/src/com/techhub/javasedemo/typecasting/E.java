package com.techhub.javasedemo.typecasting;

public class E extends D {

	public String methodE() {
		return "methodE() -> Class E";
	}
}
