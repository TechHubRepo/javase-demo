package com.techhub.javasedemo.controlstatements;

public class MainClass {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++) {
			
			if(i==2) {
				continue;
			}
			System.out.println(i);
			
		}
		
	
	}
}
