package com.techhub.javasedemo.modifiers;

class TestA {

}
