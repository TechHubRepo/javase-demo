package com.techhub.javasedemo.modifiers;

public class HelloMainClass {

	public static void main(String[] args) {
	
//		TestA testA=new TestA();
		
		Hello hello=new Hello();
		
		System.out.println(hello.getF1());
		System.out.println(hello.f2);
		System.out.println(hello.f3);
		System.out.println(hello.f4);

	}

}
