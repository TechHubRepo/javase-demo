package com.techhub.javasedemo.exceptions;

public class ExceptionTypeMain {

	public static void main(String[] args) {
		System.out.println("************ Program Started ************");
//
//		File file = new File("/abc/xyz/myfile.txt");
//
//		InputStream inputStream =new FileInputStream(file);

		System.out.println("************ Program Ended ************");
	}

}
