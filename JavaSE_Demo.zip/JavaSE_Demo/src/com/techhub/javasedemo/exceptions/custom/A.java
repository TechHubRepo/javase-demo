package com.techhub.javasedemo.exceptions.custom;

public class A {

	public void mehtod1() throws MyCheckedExceptionB {

	}
}
