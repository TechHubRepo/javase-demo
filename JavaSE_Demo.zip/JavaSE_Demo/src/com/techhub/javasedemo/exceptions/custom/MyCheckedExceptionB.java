package com.techhub.javasedemo.exceptions.custom;

public class MyCheckedExceptionB extends MyCheckedExceptionA{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyCheckedExceptionB(String msg) {
		super(msg);
	}

}
