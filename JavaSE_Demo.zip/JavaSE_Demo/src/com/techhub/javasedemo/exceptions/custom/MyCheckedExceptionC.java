package com.techhub.javasedemo.exceptions.custom;

public class MyCheckedExceptionC extends MyCheckedExceptionB{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyCheckedExceptionC(String msg) {
		super(msg);
	}

}
