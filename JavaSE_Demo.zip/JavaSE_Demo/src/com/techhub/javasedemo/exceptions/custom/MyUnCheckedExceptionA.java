package com.techhub.javasedemo.exceptions.custom;

public class MyUnCheckedExceptionA extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyUnCheckedExceptionA(String msg) {
		super(msg);
	}

}
