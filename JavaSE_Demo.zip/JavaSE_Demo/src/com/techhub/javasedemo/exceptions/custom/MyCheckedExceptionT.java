package com.techhub.javasedemo.exceptions.custom;

public class MyCheckedExceptionT extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyCheckedExceptionT(String msg) {
		super(msg);
	}

}
