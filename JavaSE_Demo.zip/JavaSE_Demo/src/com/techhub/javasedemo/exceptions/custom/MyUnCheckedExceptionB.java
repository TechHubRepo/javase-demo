package com.techhub.javasedemo.exceptions.custom;

public class MyUnCheckedExceptionB extends MyUnCheckedExceptionA{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyUnCheckedExceptionB(String msg) {
		super(msg);
	}

}
