package com.techhub.javasedemo.exceptions.custom;

public class B extends A {

	@Override
	public void mehtod1() throws MyCheckedExceptionC {

	}
}
