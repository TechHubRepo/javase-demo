package com.techhub.javasedemo.exceptions.custom;

public class MyUnCheckedExceptionT extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyUnCheckedExceptionT(String msg) {
		super(msg);
	}

}
