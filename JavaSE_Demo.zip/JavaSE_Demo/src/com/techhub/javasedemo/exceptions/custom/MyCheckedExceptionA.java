package com.techhub.javasedemo.exceptions.custom;

public class MyCheckedExceptionA extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MyCheckedExceptionA(String msg) {
		super(msg);
	}

}
