package com.techhub.javasedemo.exceptions;

public class PersonException extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PersonException(String msg) {
		super(msg);
	}
}
