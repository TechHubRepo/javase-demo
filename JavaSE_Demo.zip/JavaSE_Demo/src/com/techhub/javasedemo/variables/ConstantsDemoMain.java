package com.techhub.javasedemo.variables;

public class ConstantsDemoMain {
	
	public static void main(String[] args) {
		
		ConstantsDemo constantsDemo=new ConstantsDemo();
		System.out.println(constantsDemo.getAPPLICATION_NAME());
		
	}
}
