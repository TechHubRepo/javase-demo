package com.techhub.javasedemo.variables;

public class ConstantsDemo {

	public static final String APPLICATION_NAME;
	
	static{
		APPLICATION_NAME="My Application";
	}

	public String getAPPLICATION_NAME() {
		return APPLICATION_NAME;
	}
}
