package com.techhub.javasedemo.generic;

public class U {

	public String getU() {
		return "U";
	}

}
