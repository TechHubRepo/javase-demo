package com.techhub.javasedemo.generic;

public class AlphaWriter extends X implements Y, Z {

	@Override
	public String getZ() {
		return "Z";
	}

	@Override
	public String getY() {
		return "Y";
	}

}
