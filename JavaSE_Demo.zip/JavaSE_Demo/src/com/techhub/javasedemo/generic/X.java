package com.techhub.javasedemo.generic;

public class X {

	public String getX() {
		return "X";
	}

}
