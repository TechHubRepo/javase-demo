package com.techhub.javasedemo.generic;

public interface Y {

	public String getY();

}
