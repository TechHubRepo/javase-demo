package com.techhub.javasedemo.generic;

public interface Z {

	public String getZ();

}
