package com.techhub.javasedemo.operators;

public class AssignmentOperators {

	public static void main(String[] args) {
		int x = 13, y = 5;

//		int result = x + y;

//		x=x+y;

		x %= y; // x=x+y;

		System.out.println("Result : " + x);

	}

}
