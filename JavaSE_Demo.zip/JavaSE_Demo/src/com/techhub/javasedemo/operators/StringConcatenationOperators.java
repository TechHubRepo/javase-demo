package com.techhub.javasedemo.operators;

public class StringConcatenationOperators {

	public static void main(String[] args) {
		
		String s1="Hello";
		String s2="World";
		
		int x=10;
		int y=20;
		
		String result=s1+x+y+s2;

		System.out.println(result);
	}
}
