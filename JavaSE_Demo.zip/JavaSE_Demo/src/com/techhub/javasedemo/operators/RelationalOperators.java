package com.techhub.javasedemo.operators;

public class RelationalOperators {

	public static void main(String[] args) {

		int x = 8, y = 8;
		
		if (x > y) {
			System.out.println("x is Greater than y");
		}

		if (x >= y) {
			System.out.println("x is Greater than or equal to y");
		}

		if (x < y) {
			System.out.println("x is Less than y");
		}

		if (x <= y) {
			System.out.println("x is Less than or equal to  y");
		}

		if (x == y) {
			System.out.println("x is equal to  y");
		}

		if (x != y) {
			System.out.println("x is not equal to  y");
		}

	}

}
