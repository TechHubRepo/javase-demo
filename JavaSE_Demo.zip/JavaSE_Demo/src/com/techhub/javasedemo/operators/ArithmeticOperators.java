package com.techhub.javasedemo.operators;

public class ArithmeticOperators {

	public static void main(String[] args) {

		int x = 13, y = 5;

		System.out.println(+x);
		System.out.println(-x);

		System.out.println("(x+y) : " + (x + y));
		System.out.println("(x-y) : " + (x - y));
		System.out.println("(x*y) : " + (x * y));
		System.out.println("(x/y) : " + (x / y));
		System.out.println("(x%y) : " + (x % y));

	}
}
