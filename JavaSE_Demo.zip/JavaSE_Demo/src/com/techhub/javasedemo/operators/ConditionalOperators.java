package com.techhub.javasedemo.operators;

public class ConditionalOperators {

	public static void main(String[] args) {

		int x = 3, y = 2;

		int result = (x + y > 2) ? 100 : 50;
		
		System.out.print(result);
	}
}
