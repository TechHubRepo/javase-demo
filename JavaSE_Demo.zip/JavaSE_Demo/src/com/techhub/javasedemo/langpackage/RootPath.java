package com.techhub.javasedemo.langpackage;

public class RootPath {

	private RootPath() {
	}

	public static final String ROOT = "/home/ramniwash/TEMP_FILES/";
}
