package com.techhub.javasedemo.langpackage.thread.synchroniziation;

public class AutoGunFiringMachineMain {

	public static void main(String[] args) {
		AutoGunFiringMachine autoFiringMachine = new AutoGunFiringMachine(302);
		autoFiringMachine.start();
	}
}
