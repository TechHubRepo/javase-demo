package com.techhub.javasedemo.interfacedemo;

public class AeroplaneInterfaceMain {

	public static void main(String[] args) {

		Aeroplane aeroplane = new Aeroplane();

		aeroplane.start();
		aeroplane.move();
		aeroplane.fly();
	}

}
