package com.techhub.javasedemo.interfacedemo;

@FunctionalInterface
public interface MyFunctionInterface {

	public void myFunction(String name,int num);
	
}
