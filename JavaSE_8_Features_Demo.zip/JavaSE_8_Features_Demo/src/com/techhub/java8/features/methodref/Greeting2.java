package com.techhub.java8.features.methodref;

public class Greeting2 {

	public static String greetHello() {
		return "Greeting2 -> ::: Hello, Welcome to Java 8 Features";
	}
}
