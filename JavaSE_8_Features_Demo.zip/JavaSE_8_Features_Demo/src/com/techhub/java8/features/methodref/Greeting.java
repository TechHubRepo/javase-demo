package com.techhub.java8.features.methodref;

public class Greeting {

	public String greetNameste() {
		return "Greeting -> ::: Nameste, Welcome to Java 8 Features";
	}
}
