package com.techhub.java8.features.methodref;

@FunctionalInterface
public interface Greetable {
	
	public abstract String greet();
}
