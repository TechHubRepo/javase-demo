package com.techhub.demo.jdbc.util;

/**
 * The Paths class
 * 
 * @author ramniwash
 */
public class Paths {

	/** Private Constructor to prevent object creation */
	private Paths() {
	}

	/** The ROOT */
	public static final String ROOT = "/home/ramniwash/TEMP_FILE";
}
