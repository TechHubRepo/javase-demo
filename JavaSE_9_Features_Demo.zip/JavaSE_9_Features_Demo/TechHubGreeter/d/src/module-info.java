module d {
    requires b;
}