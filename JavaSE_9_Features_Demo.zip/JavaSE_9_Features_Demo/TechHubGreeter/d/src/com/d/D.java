package com.d;

public class D {
    public static String name(){
        return "D";
    }
}
