module com.techhub.greeter {
    requires com.techhub.greeter.service.api;
    uses  com.techhub.greeter.service.api.GreeterService;
}