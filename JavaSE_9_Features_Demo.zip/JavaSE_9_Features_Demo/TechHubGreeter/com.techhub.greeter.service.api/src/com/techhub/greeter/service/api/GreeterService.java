package com.techhub.greeter.service.api;

public interface GreeterService {

    public String greet(String name);
}
