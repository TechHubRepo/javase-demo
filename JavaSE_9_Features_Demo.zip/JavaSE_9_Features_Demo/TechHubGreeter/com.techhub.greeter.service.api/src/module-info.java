module com.techhub.greeter.service.api {
    exports com.techhub.greeter.service.api;
}