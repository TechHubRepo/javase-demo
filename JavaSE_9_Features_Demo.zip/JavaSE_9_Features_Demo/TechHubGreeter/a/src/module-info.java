module a {
    exports com.a;
}