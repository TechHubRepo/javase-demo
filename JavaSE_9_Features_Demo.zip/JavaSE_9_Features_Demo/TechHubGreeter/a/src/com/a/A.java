package com.a;

public class A {

    public static String name(){
        return "A";
    }
}
