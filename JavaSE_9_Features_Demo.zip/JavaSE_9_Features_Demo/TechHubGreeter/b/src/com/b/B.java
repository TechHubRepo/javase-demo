package com.b;

public class B {
    public static String name(){
        return "B";
    }
}
