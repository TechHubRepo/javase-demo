module b {
    requires transitive a ;
    exports com.b;
}