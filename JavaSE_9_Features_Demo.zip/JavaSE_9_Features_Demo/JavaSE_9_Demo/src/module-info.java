module JavaSE_9_Demo {
	requires java.base;
	requires techhub.util;
}