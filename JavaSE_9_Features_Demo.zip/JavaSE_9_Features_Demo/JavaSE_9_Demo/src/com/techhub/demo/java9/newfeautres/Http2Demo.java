package com.techhub.demo.java9.newfeautres;


import java.net.URI;
//import java.net.http.*;

 
public class Http2Demo {
    public static void main(String[] args) {
    	
//        try {
//            HttpClient client = HttpClient.newHttpClient();
//            // Creating a GET request
//            HttpRequest httpRequest = HttpRequest.newBuilder().uri(new URI("https://www.google.com/")).GET().build();
//            HttpResponse<String> httpResponse = client.send(httpRequest, HttpResponse.BodyHandler.asString());
//            System.out.println("\n" + httpResponse.body());
//        } catch (Exception e) {
//            System.out.println("Error: " + e.getMessage());
//        }
    }
}
