package com.techhub.demo.java9.newfeautres;

public class NoSinglUnderscore {

//	private static String _ = "Welocme";
	
	public static void main(String[] args) {
//		System.out.println(_);
	}
}
