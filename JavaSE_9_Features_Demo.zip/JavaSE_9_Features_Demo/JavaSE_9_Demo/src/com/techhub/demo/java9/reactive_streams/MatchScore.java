package com.techhub.demo.java9.reactive_streams;

public class MatchScore {

	private int score;
	private byte overNumber;
	private byte overBalls;

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public byte getOverNumber() {
		return overNumber;
	}

	public void setOverNumber(byte overNumber) {
		this.overNumber = overNumber;
	}

	public byte getOverBalls() {
		return overBalls;
	}

	public void setOverBalls(byte overBalls) {
		this.overBalls = overBalls;
	}
}
