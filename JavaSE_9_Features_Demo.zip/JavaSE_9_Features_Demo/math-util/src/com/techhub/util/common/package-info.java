/**
 * This package is related to common util
 * 
 */
package com.techhub.util.common;