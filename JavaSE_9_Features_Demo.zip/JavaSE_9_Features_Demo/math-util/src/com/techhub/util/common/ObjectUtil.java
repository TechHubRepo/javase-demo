package com.techhub.util.common;

public final class ObjectUtil {

	public static final boolean isNull(Object obj) {
		return obj == null ? true : false;
	}
}
