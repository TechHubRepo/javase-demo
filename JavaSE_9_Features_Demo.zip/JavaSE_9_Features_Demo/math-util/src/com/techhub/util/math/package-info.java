/**
 * This package is related to math-util
 */
package com.techhub.util.math;